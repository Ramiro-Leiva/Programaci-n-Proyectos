package ar.com.practico5.services;

import ar.com.practico5.entities.Lotes;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ILotesServices {
    List<Lotes> getAll();
    Page<Lotes> findAll(Pageable pageable);
    List<Lotes> findByDescrip(String descrip);
    Lotes get(Integer id);
    void save(Lotes entity);
    String delete(Lotes entity);
}
