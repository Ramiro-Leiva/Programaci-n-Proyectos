package ar.com.practico5.servicesimp;

import ar.com.practico5.dao.ICompradoresDao;
import ar.com.practico5.entities.Compradores;
import ar.com.practico5.services.ICompradoresServices;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompradoresService implements ICompradoresServices {

    @Autowired
    private ICompradoresDao entityDao;

    public List<Compradores> getAll() { return entityDao.findAll(Sort.by(Sort.Direction.ASC,"nombre"));}

    public Page<Compradores> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "nombre")));
    }

    public List<Compradores> findByDescrip(String nombre) {return entityDao.findByDescrip("%" + nombre + "%"); }


    public Compradores get(Integer id) {
        return entityDao.findById(id).orElse(null);
    }

    @Transactional
    public void save(Compradores entity) { entityDao.save(entity);}

    @Transactional
    public String delete(Compradores entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }
}
