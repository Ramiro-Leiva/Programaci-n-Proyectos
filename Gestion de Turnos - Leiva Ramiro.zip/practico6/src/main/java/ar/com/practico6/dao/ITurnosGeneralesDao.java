package ar.com.practico6.dao;

import ar.com.practico6.entities.TurnosGenerales;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ITurnosGeneralesDao extends JpaRepository<TurnosGenerales, String> {

    Page<TurnosGenerales> findAll(Pageable pageable);
}
