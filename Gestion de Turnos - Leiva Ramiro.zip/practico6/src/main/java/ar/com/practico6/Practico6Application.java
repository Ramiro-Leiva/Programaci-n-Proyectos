package ar.com.practico6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practico6Application {

	public static void main(String[] args) {
		SpringApplication.run(Practico6Application.class, args);
	}

}
