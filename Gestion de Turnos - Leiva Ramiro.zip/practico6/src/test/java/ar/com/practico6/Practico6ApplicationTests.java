package ar.com.practico6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practico6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
