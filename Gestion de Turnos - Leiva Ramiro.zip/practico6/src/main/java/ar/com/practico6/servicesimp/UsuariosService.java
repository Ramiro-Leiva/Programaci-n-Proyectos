package ar.com.practico6.servicesimp;

import ar.com.practico6.dao.IUsuariosDao;
import ar.com.practico6.entities.Usuarios;
import ar.com.practico6.services.IUsuariosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UsuariosService implements IUsuariosService {

    @Autowired
    private IUsuariosDao entityDao;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<Usuarios> getAll() {
        return entityDao.findAll(Sort.by(Sort.Direction.ASC, "usuario"));
    }

    public Page<Usuarios> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "usuario")));
    }

    public List<Usuarios> findByDescrip(String descrip) {
        return entityDao.findByDescrip("%" + descrip + "%");
    }


    public Usuarios get(Integer id) {
        return entityDao.findById(id).orElse(null);
    }

    @Transactional
    public void save(Usuarios entity) {
        //BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        entity.setContrasenia(passwordEncoder.encode(entity.getContrasenia()));
        entityDao.save(entity);
    }

    @Transactional
    public String delete(Usuarios entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }

    public Usuarios findUsuario(String usuario, String contrasenia) {
        List<Usuarios> result = entityDao.findUsuario(usuario, contrasenia, PageRequest.of(0, 1));
        try {
            if (result == null) {
                return null;
            } else {
                return result.get(0);
            }
        } catch (Exception e) {
            return null;
        }
    }

}

