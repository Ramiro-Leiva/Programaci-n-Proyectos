package ar.com.practico5.dao;

import ar.com.practico5.entities.Gastos;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IGastosDao extends JpaRepository<Gastos, Integer> {
    Page<Gastos> findAll(Pageable pageable);
}
