package ar.com.practico6.services;

import ar.com.practico6.entities.ObrasSociales;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IObrasSocialesService {
    List<ObrasSociales> getAll();
    Page<ObrasSociales> findAll(Pageable pageable);
    List<ObrasSociales> findByDescrip(String descrip);
    ObrasSociales get(String id);
    void save(ObrasSociales entity);
    String delete(ObrasSociales entity);
}
