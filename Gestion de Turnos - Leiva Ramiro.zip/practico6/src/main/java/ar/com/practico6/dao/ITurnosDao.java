package ar.com.practico6.dao;

import ar.com.practico6.entities.Turnos;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ITurnosDao extends JpaRepository<Turnos, String> {

    Page<Turnos> findAll(Pageable pageable);
}
