package ar.com.practico5.controller;


import ar.com.practico5.entities.Cultivos;
import ar.com.practico5.entities.Lotes;
import ar.com.practico5.entities.Plantaciones;
import ar.com.practico5.services.ICultivosServices;
import ar.com.practico5.services.ILotesServices;
import ar.com.practico5.services.IPlantacionesServices;

import ar.com.practico5.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class PlantacionesController {

    @Autowired
    IPlantacionesServices entityService;
    @Autowired
    ICultivosServices cultivosServices;
    @Autowired
    ILotesServices lotesServices;
   
    @RequestMapping(value = "/plantaciones", method = RequestMethod.GET)    
    public String list(Model model, Pageable pageable) {        
        Page<Plantaciones> centroPage = entityService.findAll(pageable);
        PageWrapper<Plantaciones> page = new PageWrapper<Plantaciones>(centroPage, "/plantaciones");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Plantaciones());
        return "../plantaciones/index";
    }

    @RequestMapping("/plantaciones/refresh")
    public String refresh() {
        return "redirect:/plantaciones";
    }


    @RequestMapping("/plantaciones/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Plantaciones());
        List<Cultivos> list = cultivosServices.getAll();
        model.addAttribute("cultivos", list);
        List<Lotes> list2 = lotesServices.getAll();
        model.addAttribute("lotes", list2);
        return "../plantaciones/edit";
    }

    @RequestMapping("/plantaciones/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Cultivos> list = cultivosServices.getAll();
        model.addAttribute("cultivos", list);
        List<Lotes> list2 = lotesServices.getAll();
        model.addAttribute("lotes", list2);
        return "../plantaciones/edit";
    }

    @RequestMapping(value = "plantaciones", method = RequestMethod.POST)
    public String save(Model model, @Validated Plantaciones entity) {
        String errores = "";
        if (entity.getFecha() == null) {
            errores += "Debe ingresar una fecha. ";
        }

        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Cultivos> list = cultivosServices.getAll();
            model.addAttribute("cultivos", list);
            List<Lotes> list2 = lotesServices.getAll();
            model.addAttribute("lotes", list2);
            return "../plantaciones/edit";
        }

        entityService.save(entity);
        return "redirect:/plantaciones";
    }

    @RequestMapping("plantaciones/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Plantaciones entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/plantaciones";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Plantaciones> centroPage = entityService.findAll(pageable);
            PageWrapper<Plantaciones> page = new PageWrapper<Plantaciones>(centroPage, "/plantaciones");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Plantaciones());
            return "../plantaciones/index";
        }
    }   
    
}