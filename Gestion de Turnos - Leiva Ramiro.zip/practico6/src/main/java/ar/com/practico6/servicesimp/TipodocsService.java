package ar.com.practico6.servicesimp;

import ar.com.practico6.dao.ITipodocsDao;
import ar.com.practico6.entities.Tipodocs;
import ar.com.practico6.services.ITipodocsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TipodocsService implements ITipodocsService {

    @Autowired
    private ITipodocsDao entityDao;

    public List<Tipodocs> getAll() {
        return entityDao.findAll(Sort.by(Sort.Direction.ASC, "descrip"));
    }

    public Page<Tipodocs> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "descrip")));
    }

    public List<Tipodocs> findByDescrip(String descrip) {
        return entityDao.findByDescrip("%" + descrip + "%");
    }

    public Tipodocs get(Integer id) {
        return entityDao.findById(id).orElse(null);
    }

    @Transactional
    public void save(Tipodocs entity) {
        entityDao.save(entity);
    }

    @Transactional
    public String delete(Tipodocs entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }
}
