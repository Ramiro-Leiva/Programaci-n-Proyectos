package ar.com.practico6.dao;

import ar.com.practico6.entities.ObrasSociales;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IObrasSocialesDao extends JpaRepository<ObrasSociales, String> {
    @Query("select c from ObrasSociales c where c.nombre like ?1")
    public List<ObrasSociales> findByDescrip(String name);
    
    Page<ObrasSociales> findAll(Pageable pageable);
}
