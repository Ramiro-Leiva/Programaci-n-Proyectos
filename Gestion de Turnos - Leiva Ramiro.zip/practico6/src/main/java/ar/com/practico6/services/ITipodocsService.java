package ar.com.practico6.services;

import ar.com.practico6.entities.Tipodocs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ITipodocsService {
    List<Tipodocs> getAll();
    Page<Tipodocs> findAll(Pageable pageable);
    List<Tipodocs> findByDescrip(String descrip);
    Tipodocs get(Integer id);
    void save(Tipodocs entity);
    String delete(Tipodocs entity);
}
