package ar.com.practico6.controller;


import ar.com.practico6.entities.*;
import ar.com.practico6.services.*;
import ar.com.practico6.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class TurnosProfesionalesController {

    @Autowired
    ITurnosProfesionalesService entityService;
    @Autowired
    IProfesionalesService profeService;
    @Autowired
    ITurnosGeneralesService turnoService;
   
   
    @RequestMapping(value = "/turnosprofesionales", method = RequestMethod.GET)    
    public String list(Model model, Pageable pageable) {        
        Page<TurnosProfesionales> centroPage = entityService.findAll(pageable);
        PageWrapper<TurnosProfesionales> page = new PageWrapper<TurnosProfesionales>(centroPage, "/turnosprofesionales");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new TurnosProfesionales());
        return "../turnosprofesionales/index";
    }

    @RequestMapping("/turnosprofesionales/refresh")
    public String refresh() {
        return "redirect:/turnosprofesionales";
    }

    @RequestMapping(value = "/turnosprofesionales/search", method = RequestMethod.POST)
    public String search(Model model, TurnosProfesionales entity) {
        return refresh();
    }

    @RequestMapping("/turnosprofesionales/create/{id}")
    public String create(@PathVariable String id, Model model) {
        model.addAttribute("entity", new TurnosProfesionales());
        List<Profesionales> list = profeService.getAll();
        model.addAttribute("profesionales", list);
        List<TurnosGenerales> list2 = turnoService.getAll();
        model.addAttribute("turnosgenerales", list2);
        return "../turnosprofesionales/edit";
    }

    @RequestMapping("/turnosprofesionales/edit/{id}")
    public String edit(@PathVariable String id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Profesionales> list = profeService.getAll();
        model.addAttribute("profesionales", list);
        List<TurnosGenerales> list2 = turnoService.getAll();
        model.addAttribute("turnosgenerales", list2);
        return "../turnosprofesionales/edit";
    }

    @RequestMapping(value = "turnosprofesionales", method = RequestMethod.POST)
    public String save(Model model, @Validated TurnosProfesionales entity) {
        String errores = "";
        
        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Profesionales> list = profeService.getAll();
            model.addAttribute("profesionales", list);
            List<TurnosGenerales> list2 = turnoService.getAll();
            model.addAttribute("turnosgenerales", list2);
            return "../turnosprofesionales/edit";
        }

        entityService.save(entity);
        return "redirect:/turnosprofesionales";
    }

    @RequestMapping("turnosprofesionales/delete/{id}")
    public String delete(@PathVariable String id, Model model, Pageable pageable) {
        try {
            TurnosProfesionales entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/turnosprofesionales";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<TurnosProfesionales> centroPage = entityService.findAll(pageable);
            PageWrapper<TurnosProfesionales> page = new PageWrapper<TurnosProfesionales>(centroPage, "/turnosprofesionales");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new TurnosProfesionales());
            return "../turnosprofesionales/index";
        }
    }   
    
}