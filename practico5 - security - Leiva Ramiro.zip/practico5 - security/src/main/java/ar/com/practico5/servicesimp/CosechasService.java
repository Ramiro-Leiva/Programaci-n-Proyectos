package ar.com.practico5.servicesimp;

import ar.com.practico5.dao.ICosechasDao;
import ar.com.practico5.entities.Compradores;
import ar.com.practico5.entities.Cosechas;
import ar.com.practico5.services.ICosechasServices;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CosechasService implements ICosechasServices {

    @Autowired
    private ICosechasDao entityDao;

    public List<Cosechas> getAll() { return entityDao.findAll(Sort.by(Sort.Direction.ASC, "descrip"));}

    public Page<Cosechas> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "fecha")));
    }

    public Cosechas get(Integer id) { return entityDao.findById(id).orElse(null);}

    @Transactional
    public void save(Cosechas entity) {  entityDao.save(entity);}

    @Transactional
    public String delete(Cosechas entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }
}
