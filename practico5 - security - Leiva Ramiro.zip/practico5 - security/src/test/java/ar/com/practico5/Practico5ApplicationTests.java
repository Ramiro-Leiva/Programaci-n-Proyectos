package ar.com.practico5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practico5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
