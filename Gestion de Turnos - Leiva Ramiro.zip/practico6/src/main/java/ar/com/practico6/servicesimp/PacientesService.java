package ar.com.practico6.servicesimp;

import ar.com.practico6.dao.IPacientesDao;
import ar.com.practico6.entities.Pacientes;
import ar.com.practico6.services.IPacientesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PacientesService implements IPacientesService {

    @Autowired
    private IPacientesDao entityDao;

    public List<Pacientes> getAll() {
        return entityDao.findAll(Sort.by(Sort.Direction.ASC, "nombre"));
    }

    public Page<Pacientes> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "nombre")));
    }

    public List<Pacientes> findByDescrip(String nombre) {
        return entityDao.findByDescrip("%" + nombre + "%");
    }


    public Pacientes get(Integer id) {
        return entityDao.findById(id).orElse(null);
    }

    @Transactional
    public void save(Pacientes entity) {entityDao.save(entity);}

    @Transactional
    public String delete(Pacientes entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }

}

