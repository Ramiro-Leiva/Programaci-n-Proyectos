package ar.com.practico5.controller;


import ar.com.practico5.entities.Compradores;
import ar.com.practico5.entities.Ventas;
import ar.com.practico5.entities.Plantaciones;
import ar.com.practico5.services.ICompradoresServices;
import ar.com.practico5.services.IVentasServices;
import ar.com.practico5.services.IPlantacionesServices;
import ar.com.practico5.services.IVentasServices;
import ar.com.practico5.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class VentasController {

    @Autowired
    IVentasServices entityService;
    @Autowired
    IPlantacionesServices plantacionesServices;
    @Autowired
    ICompradoresServices compradoresServices;
   
   
    @RequestMapping(value = "/ventas", method = RequestMethod.GET)
    public String list(Model model, Pageable pageable) {        
        Page<Ventas> centroPage = entityService.findAll(pageable);
        PageWrapper<Ventas> page = new PageWrapper<Ventas>(centroPage, "/ventas");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Ventas());
        return "../ventas/index";
    }

    @RequestMapping("/ventas/refresh")
    public String refresh() {
        return "redirect:/ventas";
    }


    @RequestMapping("/ventas/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Ventas());
        List<Plantaciones> list = plantacionesServices.getAll();
        model.addAttribute("plantaciones", list);
        List<Compradores> list2 = compradoresServices.getAll();
        model.addAttribute("compradores", list2);
        return "../ventas/edit";
    }

    @RequestMapping("/ventas/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Plantaciones> list = plantacionesServices.getAll();
        model.addAttribute("plantaciones", list);
        List<Compradores> list2 = compradoresServices.getAll();
        model.addAttribute("compradores", list2);
        return "../ventas/edit";
    }

    @RequestMapping(value = "ventas", method = RequestMethod.POST)
    public String save(Model model, @Validated Ventas entity) {
        String errores = "";
        if (entity.getFecha() == null) {
            errores += "Debe ingresar una fecha. ";
        }

        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Plantaciones> list = plantacionesServices.getAll();
            model.addAttribute("plantaciones", list);
            List<Compradores> list2 = compradoresServices.getAll();
            model.addAttribute("compradores", list2);
            return "../ventas/edit";
        }

        entityService.save(entity);
        return "redirect:/ventas";
    }

    @RequestMapping("ventas/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Ventas entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/ventas";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Ventas> centroPage = entityService.findAll(pageable);
            PageWrapper<Ventas> page = new PageWrapper<Ventas>(centroPage, "/ventas");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Ventas());
            return "../ventas/index";
        }
    }   
    
}