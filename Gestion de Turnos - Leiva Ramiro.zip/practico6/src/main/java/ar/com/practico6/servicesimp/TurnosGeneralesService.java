package ar.com.practico6.servicesimp;

import ar.com.practico6.dao.ITurnosGeneralesDao;
import ar.com.practico6.entities.TurnosGenerales;
import ar.com.practico6.services.ITurnosGeneralesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TurnosGeneralesService implements ITurnosGeneralesService {

    @Autowired
    private ITurnosGeneralesDao entityDao;

    public List<TurnosGenerales> getAll() {
        return entityDao.findAll(Sort.by(Sort.Direction.ASC, "id"));
    }

    public Page<TurnosGenerales> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "id")));
    }


    public TurnosGenerales get(String id) {
        return entityDao.findById(id).orElse(null);
    }

    @Transactional
    public void save(TurnosGenerales entity) {entityDao.save(entity);}

    @Transactional
    public String delete(TurnosGenerales entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }

}

