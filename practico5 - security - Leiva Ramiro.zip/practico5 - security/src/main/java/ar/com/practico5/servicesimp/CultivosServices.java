package ar.com.practico5.servicesimp;

import ar.com.practico5.dao.ICultivosDao;
import ar.com.practico5.entities.Cultivos;
import ar.com.practico5.services.ICultivosServices;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CultivosServices implements ICultivosServices {

    @Autowired
    private ICultivosDao entityDao;

    public List<Cultivos> getAll() { return  entityDao.findAll(Sort.by(Sort.Direction.ASC, "descrip"));}

    public Page<Cultivos> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "descrip")));
    }
    public List<Cultivos> findByDescrip(String descrip) { return entityDao.findByDescrip("%" + descrip +"%"); }

    public Cultivos get(Integer id) {
        return entityDao.findById(id).orElse(null);
    }

    @Transactional
    public void save(Cultivos entity) {entityDao.save(entity); }

    @Transactional
    public String delete(Cultivos entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }
}
