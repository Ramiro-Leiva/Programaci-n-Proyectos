package ar.com.practico6.servicesimp;

import ar.com.practico6.dao.IUsuariosDao;
import ar.com.practico6.entities.Usuarios;
import ar.com.practico6.security.UserDetailsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@Qualifier("userDetailsService")
public class UsuarioDetalleServiceImpl implements UserDetailsService {
    @Autowired
    private IUsuariosDao dao;

    @Override
    public UserDetails loadUserByUsername(String usuario) throws UsernameNotFoundException {
        final Usuarios retrievedUser = dao.findOneByUsuario(usuario);

        if (retrievedUser == null) {
            throw new UsernameNotFoundException("Usuario o Password Inválido(s)");
        }

        return UserDetailsMapper.build(retrievedUser);
    }

}

