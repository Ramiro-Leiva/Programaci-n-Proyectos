package ar.com.practico6.servicesimp;

import ar.com.practico6.dao.ITurnosProfesionalesDao;
import ar.com.practico6.entities.TurnosProfesionales;
import ar.com.practico6.services.ITurnosProfesionalesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TurnosProfesionalesService implements ITurnosProfesionalesService {

    @Autowired
    private ITurnosProfesionalesDao entityDao;

    public List<TurnosProfesionales> getAll() {
        return entityDao.findAll(Sort.by(Sort.Direction.ASC, "id"));
    }

    public Page<TurnosProfesionales> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "id")));
    }


    public TurnosProfesionales get(String id) {
        return entityDao.findById(id).orElse(null);
    }

    @Transactional
    public void save(TurnosProfesionales entity) {entityDao.save(entity);}

    @Transactional
    public String delete(TurnosProfesionales entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }

}

