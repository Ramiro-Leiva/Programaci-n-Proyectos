package ar.com.practico5.dao;

import ar.com.practico5.entities.Plantaciones;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IPlantacionesDao extends JpaRepository<Plantaciones, Integer> {
    Page<Plantaciones> findAll(Pageable pageable);

}
