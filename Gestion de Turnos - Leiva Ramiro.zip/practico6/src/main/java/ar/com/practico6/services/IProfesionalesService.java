package ar.com.practico6.services;

import ar.com.practico6.entities.Profesionales;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IProfesionalesService {
    List<Profesionales> getAll();
    Profesionales get(Integer id);
    void save(Profesionales entity);
    String delete(Profesionales entity);
    Page<Profesionales> findAll(Pageable pageable);
    List<Profesionales> findByDescrip(String nombre);
    ;
}
