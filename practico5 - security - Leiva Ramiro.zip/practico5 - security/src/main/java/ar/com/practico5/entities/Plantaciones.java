package ar.com.practico5.entities;

import jakarta.persistence.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "plantaciones")
public class Plantaciones implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String periodo;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fecha;
    private Double porcentaje_lote;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date fecha_cierre;

    @JoinColumn(name = "cultivos_id", referencedColumnName = "id")
    @ManyToOne
    private Cultivos cultivos;

    @JoinColumn(name = "lote_id", referencedColumnName = "id")
    @ManyToOne
    private Lotes lotes;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Double getPorcentaje_lote() {
        return porcentaje_lote;
    }

    public void setPorcentaje_lote(Double porcentaje_lote) {
        this.porcentaje_lote = porcentaje_lote;
    }

    public Date getFecha_cierre() {
        return fecha_cierre;
    }

    public void setFecha_cierre(Date fecha_cierre) {
        this.fecha_cierre = fecha_cierre;
    }

    public Cultivos getCultivos() {
        return cultivos;
    }

    public void setCultivos(Cultivos cultivos) {
        this.cultivos = cultivos;
    }

    public Lotes getLotes() {
        return lotes;
    }

    public void setLotes(Lotes lotes) {
        this.lotes = lotes;
    }
}
