package ar.com.practico6.services;

import ar.com.practico6.entities.Turnos;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ITurnosService {
    List<Turnos> getAll();
    Turnos get(String id);
    void save(Turnos entity);
    String delete(Turnos entity);
    Page<Turnos> findAll(Pageable pageable);

}
