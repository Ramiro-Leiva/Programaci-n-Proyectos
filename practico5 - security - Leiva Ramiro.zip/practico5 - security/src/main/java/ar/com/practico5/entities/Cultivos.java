package ar.com.practico5.entities;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "cultivos")
public class Cultivos implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String descrip;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }


    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
