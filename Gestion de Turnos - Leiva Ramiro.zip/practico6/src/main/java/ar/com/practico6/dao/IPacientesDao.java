package ar.com.practico6.dao;

import ar.com.practico6.entities.Pacientes;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IPacientesDao extends JpaRepository<Pacientes, Integer> {
    @Query("select c from Pacientes c where c.nombre like ?1")
    List<Pacientes> findByDescrip(String name);

    Page<Pacientes> findAll(Pageable pageable);
}
