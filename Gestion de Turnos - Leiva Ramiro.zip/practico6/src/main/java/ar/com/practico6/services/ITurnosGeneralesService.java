package ar.com.practico6.services;

import ar.com.practico6.entities.TurnosGenerales;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ITurnosGeneralesService {
    List<TurnosGenerales> getAll();
    TurnosGenerales get(String id);
    void save(TurnosGenerales entity);
    String delete(TurnosGenerales entity);
    Page<TurnosGenerales> findAll(Pageable pageable);

}
